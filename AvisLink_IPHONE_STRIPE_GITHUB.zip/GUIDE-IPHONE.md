# AvisLink Stripe Test — déploiement depuis un iPhone

Ce paquet contient `public/` (site), `functions/` (API Stripe côté serveur), `netlify.toml` (configuration Netlify) et `package.json` (dépendances). **Aucun secret Stripe n’est contenu dans ce ZIP.**

## Préparation
1. Télécharge ce ZIP dans l’app **Fichiers** de ton iPhone.
2. Dans **Fichiers**, touche le ZIP une fois pour le décompresser. Tu verras le dossier `AvisLink_IPHONE_STRIPE_GITHUB`.
3. Sur Safari, connecte-toi à `github.com` (crée un compte gratuitement si nécessaire). Le mode **Version pour ordinateur** de Safari peut aider à voir tous les boutons.

## Mettre le code sur GitHub
1. Crée un dépôt **privé** nommé `avislink-stripe-test` (sans ajouter de modèle ni README automatique).
2. Dans ce dépôt GitHub, `Add file → Upload files`, ajoute les fichiers à la racine : `netlify.toml`, `package.json` et `GUIDE-IPHONE.md`, puis valide (`Commit changes`).
3. `Add file → Create new file` : saisis `public/.gitkeep` comme chemin et valide. Cela crée le dossier `public`.
4. Ouvre le dossier `public` sur GitHub, `Add file → Upload files`. Dans l’app **Fichiers** d’iOS, sélectionne les fichiers contenus dans le dossier `public` (HTML, JS, favicon, etc.) et valide.
5. De même, crée `functions/.gitkeep`, puis ouvre ce dossier GitHub et ajoute les quatre fichiers `.cjs` du dossier `functions` de ton iPhone.

Ne téléverse **pas** le ZIP tout seul dans GitHub : Netlify doit voir les vrais fichiers et dossiers. Les fichiers `.gitkeep` sont inoffensifs et peuvent rester.

## Relier GitHub au projet Netlify existant
1. Connecte-toi sur `app.netlify.com`. Ouvre **le projet existant AvisLink** qui possède l’adresse `avislink.netlify.app` (ne crée pas un nouveau projet).
2. Va à `Project configuration → Developer settings → Continuous deployment → Repository → Link repository` (les intitulés peuvent varier selon l’interface).
3. Choisis GitHub puis le dépôt `avislink-stripe-test`.
4. Vérifie : Publish directory `public`, Functions directory `functions`, base directory vide. La configuration est également dans `netlify.toml`.
5. Lance le déploiement si Netlify ne le fait pas automatiquement, puis attends le statut `Published` ou `Ready`.

## Stripe (test uniquement)
- Dans les variables d’environnement du même projet Netlify, ajoute `STRIPE_SECRET_KEY`, valeur commençant par `sk_test_...`. Ne la colle **jamais** dans GitHub ni dans les fichiers publics.
- Configure la portée `Functions` ou `All`, et le contexte `Production` pour le site principal. Les variables sont privées même si Netlify appelle ce contexte Production.
- Redéploie après l’enregistrement de la variable.
- Ouvre `https://avislink.netlify.app/stripe-test.html`.
- Appuie sur `Vérifier la connexion`. Si le compte est validé, sélectionne une offre et teste avec la carte fictive Stripe `4242 4242 4242 4242`, une expiration future et un CVC fictif.

## Diagnostic
- **404 sur `/stripe-test.html`** : les fichiers de `public/` n’ont pas été publiés ou le mauvais projet a été déployé.
- **404 sur `/.netlify/functions/stripe-test-status`** : les fonctions n’ont pas été compilées (vérifie le déploiement, le dossier `functions/` et les logs).
- **`Compte pas encore connecté`** : vérifie la variable secrète Netlify et le nouveau déploiement. Ne poste pas de capture d’écran contenant la clé.

Cette version est strictement une **simulation Stripe**. Aucun argent réel, aucune commande/expédition effective.
